# The five-in-one theme of light, dark, salt, sugar, and vinegar

* "salt" eye-protection color (used in light mode)
* "sugar" eye-protection color (colored arrow for note root directory, title color corresponding to outline, used in light mode)
* "vinegar" deep black theme color (used in dark mode).