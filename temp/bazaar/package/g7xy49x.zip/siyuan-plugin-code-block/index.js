"use strict";const s=require("siyuan");class e extends s.Plugin{}module.exports=e;
