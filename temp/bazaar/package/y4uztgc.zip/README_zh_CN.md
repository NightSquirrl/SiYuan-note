[English](https://github.com/mozhux/Remix-icon/blob/master/README.md)
Remix icon 是一套中性的开源图标包，风格统一且视觉对齐。通过对图标包的精心挑选，力求图标能准确传达功能意思。
图标包基于非常优秀的开源图标包[Remix icon](https://remixicon.com/)，感谢原作者的精心设计。

### 更新日志
3.2 补全、优化图标
3.1 补全、优化图标
3.0 适配全新集市