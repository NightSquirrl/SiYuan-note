[中文](https://github.com/mozhux/Remix-icon/blob/master/README_zh_CN.md)

It is a neutral open-source icon pack with a consistent style and visual alignment. Through careful selection of icons in the pack, the aim is for them to accurately convey their functional meaning.

The icon pack is based on the excellent open source icon pack [Remix icon](https://remixicon.com/). Thank you to the original author for their meticulous design.

### Changelog
3.2 Complete and optimize icons
3.1 Complete and optimize icons
3.0 Adapted for the brand new marketplace
